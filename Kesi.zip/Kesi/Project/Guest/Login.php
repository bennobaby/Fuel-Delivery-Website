<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>
<?php
session_start();
	include("../Assets/Connection/connection.php");
	
	if(isset($_POST["btnsave"]))
	{
		$seladmin="select * from tbl_admin where admin_email='".$_POST["txt_user"]."' and admin_password='".$_POST["txt_pass"]."'";
		$rowadmin=$con->query($seladmin);
		
		
		$selagent="select * from tbl_agent where agent_email='".$_POST["txt_user"]."' and agent_password='".$_POST["txt_pass"]."' and agent_vstatus=1";
		$rowagent=$con->query($selagent);
		
		
		$seld="select * from tbl_deliveryboy where deliveryboy_email='".$_POST["txt_user"]."' and deliveryboy_password='".$_POST["txt_pass"]."'";
		$rowd=$con->query($seld);
		
		
		
		$seluser="select * from tbl_user where user_email='".$_POST["txt_user"]."' and user_password='".$_POST["txt_pass"]."'";
		$rowuser=$con->query($seluser);
		
		
		if($dataadmin=$rowadmin->fetch_assoc())
		{
			$_SESSION["aid"]=$dataadmin["admin_id"];
			$_SESSION["aname"]=$dataadmin["admin_name"];
			header("Location:../Admin/Homepage.php");
		}
		else if($dataagent=$rowagent->fetch_assoc())
		{
			$_SESSION["aid"]=$dataagent["agent_id"];
			$_SESSION["aname"]=$dataagent["agent_name"];
			header("Location:../Agent/Homepage.php");
		}
		else if($datad=$rowd->fetch_assoc())
		{
			$_SESSION["did"]=$datad["deliveryboy_id"];
			$_SESSION["dname"]=$datad["deliveryboy_name"];
			header("Location:../DeliveryBoy/Homepage.php");
		}
		else if($datauser=$rowuser->fetch_assoc())
		{
			$_SESSION["uid"]=$datauser["user_id"];
			$_SESSION["uname"]=$datauser["user_name"];
			header("Location:../User/Homepage.php");
		}
		else{
			?>
            <script>alert("Invalid User Deatils Please Check Login Credentials......")</script>
            <?php
		}
	}
	?>
<form id="form1" name="form1" method="post" action="">
  <table border="1" cellpadding="10">
    <tr>
      <td>Email/Username</td>
      <td><label for="txt_user"></label>
      <input type="text" name="txt_user" id="txt_user" required="required" autocomplete="off"/></td>
    </tr>
    <tr>
      <td>Password</td>
      <td><label for="txt_pass"></label>
      <input type="password" name="txt_pass" id="txt_pass" required="required" autocomplete="off"/></td>
    </tr>
    <tr>
      <td colspan="2" align="center"><input type="submit" name="btnsave" id="btnsave" value="Login" /></td>
    </tr>
  </table>
</form>
</body>
</html>