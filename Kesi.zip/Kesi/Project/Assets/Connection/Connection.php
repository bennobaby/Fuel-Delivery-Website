<?php
$server="localhost";
$user="root";
$pass="";
$database="db_project";
$con=mysqli_connect($server,$user,$pass,$database);
if(!$con)
{
	echo "Database Connection Failed Guys....";
}
?>