<?php
	include("../Connection/connection.php");
	?>
<table cellpadding="60" align="center">
  <tr>
  <?php
  $sela="select * from tbl_agent a inner join tbl_place p on p.place_id=a.place_id inner join tbl_district d on d.district_id=p.district_id where a.agent_vstatus=1";
  if($_GET["did"]!=null)
  {
	  $sela.=" and p.district_id='".$_GET["did"]."'";
  }
  if($_GET["pid"]!=null)
  {
	  $sela.=" and p.place_id='".$_GET["pid"]."'";
  }
  echo $sela;
  $rowa=$con->query($sela);
  $i=0;
  while($datas=$rowa->fetch_assoc())
  {
	  $i++;
  ?>
  <td>
  <p style="text-align:center;border:1px solid #999; margin::22px;padding:10px">
  <img src="../Assets/Files/AgentPhoto/<?php echo $datas["agent_photo"]?>" width="200" height="200" />
  <br />
  Name:<?php  echo $datas["agent_name"]?><br />
  Contact:<?php echo $datas["agent_contact"]?><br />
  <a href="BookFuel.php?ag=<?php echo $datas["agent_id"]?>">Order Fuel</a>
  </p>
  </td>
  <?php
  if($i==4)
  {
	  echo "</tr>";
	  $i=0;
	  echo "<tr>";
  }
  }
  ?>
  </table>