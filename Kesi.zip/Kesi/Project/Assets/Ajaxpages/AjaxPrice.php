
<?php

    include("../Connection/connection.php");
	$sel="select * from tbl_stock  where agent_id='".$_GET["aid"]."' and category_id='".$_GET["cid"]."' and brand_id='".$_GET["did"]."'";
	$row=$con->query($sel);
		$data=$row->fetch_assoc();
		echo $data["stock_rate"];

	?>