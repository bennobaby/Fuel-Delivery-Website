 <!-- ! Footer -->
    <footer class="footer">
  <div class="container footer--flex">
    <div class="footer-start">
      <p>2021 © Elegant Dashboard - <a href="elegant-dashboard.com" target="_blank"
          rel="noopener noreferrer">elegant-dashboard.com</a></p>
    </div>
    <ul class="footer-end">
      <li><a href="##">About</a></li>
      <li><a href="##">Support</a></li>
      <li><a href="##">Puchase</a></li>
    </ul>
  </div>
</footer>
  </div>
</div>
<!-- Chart library -->
<script src="../Assets/Template/Admin/plugins/chart.min.js"></script>
<!-- Icons library -->
<script src="../Assets/Template/Admin/plugins/feather.min.js"></script>
<!-- Custom scripts -->
<script src="../Assets/Template/Admin/js/script.js"></script>