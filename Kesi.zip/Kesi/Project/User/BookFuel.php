<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<script src="../Assets/JQ/jQuery.js"></script>
<script>
function getRate()
{

var did=document.getElementById("selbrand").value;
var cid=document.getElementById("selc").value;
var sid=<?php echo $_GET["ag"] ?>

	$.ajax({
	  url:"../Assets/Ajaxpages/AjaxPrice.php?did="+did+"&cid="+cid+"&aid="+sid,
	  success: function(html){
		  document.getElementById("txt_rates").value=html;
		  document.getElementById("txt_id").value=html
	  }
	});
}
function getTotal()
{
	var q=document.getElementById("txt_qn").value;
	var r=document.getElementById("txt_id").value;
	var total =q*r;
	document.getElementById("txt_total").value=total;
}
</script>
</head>

<body>
<?php
ob_start();
session_start();
    include("../Assets/Connection/connection.php");
	if(isset($_POST["btnsave"]))
	{
		$ins="insert into tbl_booking(category_id,brand_id,booking_quantity,booking_date,agent_id,booking_amount)values('".$_POST["selc"]."','".$_POST["selbrand"]."','".$_POST["txt_qn"]."',curdate(),'".$_GET["ag"]."','".$_POST["txt_total"]."')";
		if($con->query($ins))
		{
			?>
            <script>
			alert("Booking Completed....  Few Minutes Takes For OTP Genaration... Don't Share OTP Except Our Delivery Agent");
			window.location="Homepage.php";
            </script>
            <?php
		}
		else
		{
			?>
            <script>
			alert("Server Error Please Try Again Later.....");
			window.location="Homepage.php";
            </script>
            <?php
		}
	}
	include("Head.php");
	?>
    <br /><br /><br />
     <div id="tab" align="center">
<form id="form1" name="form1" method="post" action="">
  <table border="1" cellpadding="10" align="center" style="border-collapse:collapse">
    <tr>
      <td>Brand</td>
      <td><label for="selbrand"></label>
        <select name="selbrand" id="selbrand">
        <option value="">---select---</option>
        <?php
		$sel="select * From tbl_brand";
		$row=$con->query($sel);
		while($data=$row->fetch_assoc())
		{
		?>
        <option value="<?php echo $data["brand_id"]?>"><?php echo $data["brand_name"]?></option>
        <?php
		}
		?>
      </select></td>
    </tr>
    <tr>
      <td>Category</td>
      <td><label for="selc"></label>
        <select name="selc" id="selc" onchange="getRate()">
        <option value="">---select---</option>
        <?php
		$sel="select * From tbl_category";
		$row=$con->query($sel);
		while($data=$row->fetch_assoc())
		{
		?>
        <option value="<?php echo $data["category_id"]?>"><?php echo $data["category_name"]?></option>
        <?php
		}
		?>
      </select></td>
    </tr>
    <tr>
      <td>Quantity Per litere</td>
      <td><label for="txt_rate"></label>
      <input type="number" name="txt_qn" id="txt_qn" required="required" autocomplete="off" onchange="getTotal()"/></td>
    </tr>
    <tr>
      <td>Rate (per Liter)</td>
      <td><label for="txt_rates"></label>
      <input type="hidden" id="txt_id" value="" />
      <input type="text" name="txt_rates" id="txt_rates" /></td>
    </tr>
    <tr>
      <td>Grand Total</td>
      <td><label for="txt_stock"></label>
      <input type="text" name="txt_total" id="txt_total"  readonly="readonly"/></td>
    </tr>
    <tr>
      <td colspan="2" align="center"><input type="submit" name="btnsave" id="btnsave" value="Save" />
      <input type="submit" name="btnc" id="btnc" value="Cancel" /></td>
    </tr>
  </table>
  </form>
  </div>
</body>
<br /><br /><br /><br /><br /><br />
<?php
include("Foot.php");
ob_flush();
?>
</html>