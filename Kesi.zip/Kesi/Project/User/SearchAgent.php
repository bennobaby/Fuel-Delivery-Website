<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>
<?php
ob_start();
	include("../Assets/Connection/connection.php");
	include("Head.php");
	
	?>
    <br /><br /><br />
     <div id="tab" align="center">
<form id="form1" name="form1" method="post" action="">
  <table border="1" cellpadding="10" align="center">
    <tr>
      <td>District</td>
      <td><label for="seld"></label>
        <select name="seld" id="seld" onchange="getPlace(this.value),getData()">
         <option value="">---select---</option>
        <?php
		$sel="select * from tbl_district";
		$row=$con->query($sel);
		while($data=$row->fetch_assoc())
		{
			?>
            <option  value="<?php echo $data["district_id"]?>"><?php echo $data["district_name"]?></option>
            <?php
		}
		?>
      </select></td>
      <td>Place</td>
      <td><label for="selplace"></label>
        <select name="selplace" id="selplace" onchange="getData()">
         <option value="">---select---</option>
      </select></td>
    </tr>
  </table>
  <div id="search">
  <table cellpadding="60" align="center">
  <tr>
  <?php
  $sela="select * from tbl_agent a inner join tbl_place p on p.place_id=a.place_id inner join tbl_district d on d.district_id=p.district_id where a.agent_vstatus=1";
  $rowa=$con->query($sela);
  $i=0;
  while($datas=$rowa->fetch_assoc())
  {
	  $i++;
  ?>
  <td>
  <p style="text-align:center;border:1px solid #999; margin::22px;padding:10px">
  <img src="../Assets/Files/AgentPhoto/<?php echo $datas["agent_photo"]?>" width="200" height="200" />
  <br />
  Name:<?php  echo $datas["agent_name"]?><br />
  Contact:<?php echo $datas["agent_contact"]?><br />
  <a href="BookFuel.php?ag=<?php echo $datas["agent_id"]?>">Order Fuel</a>
  </p>
  </td>
  <?php
  if($i==4)
  {
	  echo "</tr>";
	  $i=0;
	  echo "<tr>";
  }
  }
  ?>
  </table>
  </div>
</form>
</div>
</body>
<br /><br /><br /><br /><br /><br />
<?php
include("Foot.php");
ob_flush();
?>
</html>
<script src="../Assets/JQ/jQuery.js"></script>
<script>
function getPlace(did)
{

	$.ajax({
	  url:"../Assets/Ajaxpages/Ajaxplace.php?did="+did,
	  success: function(html){
		$("#selplace").html(html);
	  }
	});
}
function getData()
{
	var did=document.getElementById("seld").value;
	var pid=document.getElementById("selplace").value;

	$.ajax({
	  url:"../Assets/Ajaxpages/AjaxData.php?did="+did+"&pid="+pid,
	  success: function(html){
		$("#search").html(html);
	  }
	});
}
</script>