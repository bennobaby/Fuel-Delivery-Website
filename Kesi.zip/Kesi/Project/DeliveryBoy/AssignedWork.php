<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>
<?php
ob_start();
session_start();
    include("../Assets/Connection/connection.php");
	if(isset($_POST["btnsave"]))
	{
		$selo="select * from tbl_booking where booking_id='".$_SESSION["bid"]."' and booking_otp='".$_POST["txtnumber"]."'";
		$rowo=$con->query($selo);
		if($datao=$rowo->fetch_assoc())
		{
			$up="update tbl_assign set assign_status=1 where booking_id='".$_SESSION["bid"]."'";
			if($con->query($up))
			{
				$update="update tbl_booking set booking_status=3 where booking_id='".$_SESSION["bid"]."'";
				$con->query($update);
				header("Location:Homepage.php");
			}
		}
		else{
			?>
            <script>
			alert("Invalid OTP");
			window.location="AssignedWork.php";
            </script>
            <?php
		}
	}
	include("Head.php");
	?>
    <br /><br /><br />
     <div id="tab" align="center">
<form id="form1" name="form1" method="post" action="">
  <table border="1" cellpadding="10" align="center">
    <tr>
      <td>Sl.No</td>
      <td>Brand</td>
      <td>Category</td>
      <td>Quantity</td>
      <td>Order Address</td>
      <td>Receipient Name</td>
      <td>Action</td>
    </tr>
    <?php
	$sel="select * from tbl_assign a inner join tbl_booking b  on b.booking_id=a.booking_id inner join tbl_brand bd on bd.brand_id=b.brand_id inner join tbl_category c on c.category_id=b.category_id inner join tbl_user u on u.user_id=b.user_id where a.deliveryboy_id='".$_SESSION["did"]."'";
	$row=$con->query($sel);
	$i=0;
	while($data=$row->fetch_assoc())
	{
		$i++;
	?>
    <tr>
      <td><?php echo $i?></td>
      <td><?php echo $data["brand_name"]?></td>
      <td><?php echo $data["category_name"]?></td>
      <td><?php echo $data["booking_quantity"]?></td>
      <td><?php echo $data["user_address"]?></td>
      <td><?php echo $data["user_name"]?></td>
      <td><a href="AssignedWork.php?id=<?php echo $data["booking_id"]?>">Complete</a><?php if(isset($_GET["id"]))
	  {
		  $_SESSION["bid"]=$_GET["id"];
		  ?>
          <input type="text" name="txtnumber" placeholder="Enter OTP" /><input type="submit" name="btnsave" value="Confirm" />
          <?php
	  }?></td>
    </tr>
    <?php
	}
	?>
  </table>
</form>
</div>
</body>
<br /><br /><br /><br /><br /><br />
<?php
include("Foot.php");
ob_flush();
?>
</html>